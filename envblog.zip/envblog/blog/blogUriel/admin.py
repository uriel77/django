from django.contrib import admin
from .models import Entrada

# Register your models here.
admin.site.register(Entrada)